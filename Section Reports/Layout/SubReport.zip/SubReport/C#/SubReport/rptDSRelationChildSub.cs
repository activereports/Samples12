namespace GrapeCity.ActiveReports.Samples.SubReport
{
	/// <summary>
	/// Description of the outline of the rptDSRelationChildSub.
	/// 
	/// </summary>
	public partial class rptDSRelationChildSub : GrapeCity.ActiveReports.SectionReport
	{
		public rptDSRelationChildSub()
		{
			//
			// ActiveReport Designer support is required
			// 
			//
			InitializeComponent();
		}
	}
}
