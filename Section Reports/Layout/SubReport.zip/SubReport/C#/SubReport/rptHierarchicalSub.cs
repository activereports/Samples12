namespace GrapeCity.ActiveReports.Samples.SubReport
{
	/// <summary>
	///Description of the outline of the rptHierarchicalSub.
	///
	/// </summary>
	public partial class rptHierarchicalSub : GrapeCity.ActiveReports.SectionReport
	{
		public rptHierarchicalSub()
		{
			//
			// ActiveReport designer support is required
			//
			//
			InitializeComponent();
		}
	}
}
