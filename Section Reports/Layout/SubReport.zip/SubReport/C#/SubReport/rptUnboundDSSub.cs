namespace GrapeCity.ActiveReports.Samples.SubReport
{
	/// <summary>
	/// Description of the outline of the rptUnboundDSSub.
	/// 
	/// </summary>
	public partial class rptUnboundDSSub : GrapeCity.ActiveReports.SectionReport
	{
		public rptUnboundDSSub()
		{
			//
			// ActiveReport designer support is required.
			// 
			//
			InitializeComponent();
		}
	}
}
