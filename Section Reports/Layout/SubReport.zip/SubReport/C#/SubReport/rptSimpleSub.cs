namespace GrapeCity.ActiveReports.Samples.SubReport
{
	/// <summary>
	///  Description of the outline of the rptSimpleSub.
	///  
	/// </summary>
	public partial class rptSimpleSub : GrapeCity.ActiveReports.SectionReport
	{
		public rptSimpleSub()
		{
			//
			// ActiveReport designer support is required.
			//
			//
			InitializeComponent();
		}
	}
}
